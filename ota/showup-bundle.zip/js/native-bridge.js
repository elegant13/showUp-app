/* ==========================================================================
   ShowUp Native Bridge (Capacitor iOS / Android & Over-The-Air Updates)
   ========================================================================== */

(function (window) {
  'use strict';

  const REST_NOTIFICATION_ID = 4201;

  function isNative() {
    if (typeof window === 'undefined') return false;
    if (window.Capacitor && typeof window.Capacitor.isNativePlatform === 'function' && window.Capacitor.isNativePlatform()) {
      return true;
    }
    if (window.Capacitor && typeof window.Capacitor.getPlatform === 'function') {
      const p = window.Capacitor.getPlatform();
      if (p === 'android' || p === 'ios') return true;
    }
    if (window.androidBridge || (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.bridge)) {
      return true;
    }
    if (typeof navigator !== 'undefined' && typeof navigator.userAgent === 'string' && /; wv\)|Capacitor/i.test(navigator.userAgent)) {
      return true;
    }
    return false;
  }

  function hideNativeSplash() {
    if (typeof window !== 'undefined' && window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.SplashScreen) {
      try {
        window.Capacitor.Plugins.SplashScreen.hide({ fadeOutDuration: 200 });
      } catch (e) {}
    }
  }

  // 1. Initialize Native Plugins on device ready
  async function initNativeBridge() {
    if (!isNative()) return;

    // 1a. Immediately dismiss splash screen
    hideNativeSplash();

    // 1b. Configure Status Bar style
    try {
      if (window.Capacitor.Plugins && window.Capacitor.Plugins.StatusBar) {
        window.Capacitor.Plugins.StatusBar.setStyle({ style: 'DARK' }).catch(() => {});
        window.Capacitor.Plugins.StatusBar.setBackgroundColor({ color: '#020617' }).catch(() => {});
      }
    } catch (e) {}

    // 1c. Notify Capgo / OTA updater if present & check for self-hosted OTA bundle updates
    try {
      const updater = getCapacitorUpdaterPlugin();
      if (updater && typeof updater.notifyAppReady === 'function') {
        await updater.notifyAppReady().catch(() => {});
      }
      setTimeout(() => {
        checkAndApplyOTAUpdate().catch(() => {});
      }, 1200);
    } catch (e) {}

    // 1d. Request notification permissions gracefully on native
    try {
      if (window.Capacitor.Plugins && window.Capacitor.Plugins.LocalNotifications) {
        const perm = await window.Capacitor.Plugins.LocalNotifications.checkPermissions();
        if (perm && perm.display !== 'granted') {
          window.Capacitor.Plugins.LocalNotifications.requestPermissions().catch(() => {});
        }
      }
    } catch (e) {}

    // 1e. Initialize native GoogleAuth plugin if present
    try {
      const googleAuth = getGoogleAuthPlugin();
      if (googleAuth && typeof googleAuth.initialize === 'function') {
        const isIos = window.Capacitor.getPlatform?.() === 'ios';
        const clientId = isIos
          ? '115199141886-99m5rosha76ftskaeknj2e757mn0sb0t.apps.googleusercontent.com'
          : '489093591529-0cepullrdv1684c6e0p545850rocunfk.apps.googleusercontent.com';

        googleAuth.initialize({
          clientId: clientId,
          serverClientId: '489093591529-0cepullrdv1684c6e0p545850rocunfk.apps.googleusercontent.com',
          scopes: ['profile', 'email', 'https://www.googleapis.com/auth/drive.file'],
          grantOfflineAccess: false
        }).catch(() => {});
      }
    } catch (gErr) {
      console.warn("[NativeBridge] GoogleAuth setup notice:", gErr);
    }
  }

  const OTA_MANIFEST_URL = 'https://trackshowup.app/ota/version.json';
  let otaCheckInFlight = false;
  let lastOtaCheckAt = 0;

  function getCapacitorUpdaterPlugin() {
    if (typeof window === 'undefined' || !window.Capacitor) return null;
    if (window.Capacitor.Plugins && window.Capacitor.Plugins.CapacitorUpdater) {
      return window.Capacitor.Plugins.CapacitorUpdater;
    }
    if (typeof window.Capacitor.registerPlugin === 'function') {
      return window.Capacitor.registerPlugin('CapacitorUpdater');
    }
    if (typeof window.Capacitor.nativePromise === 'function') {
      return {
        notifyAppReady: () => window.Capacitor.nativePromise('CapacitorUpdater', 'notifyAppReady', {}),
        download: (opts) => window.Capacitor.nativePromise('CapacitorUpdater', 'download', opts || {}),
        next: (opts) => window.Capacitor.nativePromise('CapacitorUpdater', 'next', opts || {}),
        set: (opts) => window.Capacitor.nativePromise('CapacitorUpdater', 'set', opts || {}),
        list: () => window.Capacitor.nativePromise('CapacitorUpdater', 'list', {}),
        current: () => window.Capacitor.nativePromise('CapacitorUpdater', 'current', {})
      };
    }
    return null;
  }

  function isWorkoutInProgress() {
    try {
      if (typeof isSetInProgress !== 'undefined' && isSetInProgress) return true;
      if (typeof workoutTimerState !== 'undefined' && workoutTimerState && workoutTimerState !== 'stopped') return true;
      if (typeof currentSessionSets !== 'undefined' && Array.isArray(currentSessionSets) && currentSessionSets.length > 0) return true;
      const savedActive = localStorage.getItem('showUp_active_workout_sets');
      if (savedActive) {
        const parsed = JSON.parse(savedActive);
        if (Array.isArray(parsed) && parsed.length > 0) return true;
      }
    } catch (e) {}
    return false;
  }

  async function checkAndApplyOTAUpdate(force = false) {
    if (!isNative() || otaCheckInFlight) return false;
    const now = Date.now();
    if (!force && (now - lastOtaCheckAt) < 45000) return false;

    const updater = getCapacitorUpdaterPlugin();
    if (!updater || typeof updater.download !== 'function') return false;

    otaCheckInFlight = true;
    lastOtaCheckAt = now;
    try {
      const res = await fetch(`${OTA_MANIFEST_URL}?t=${now}`, { cache: 'no-store' });
      if (!res.ok) return false;
      const remote = await res.json();
      if (!remote || !remote.url || !remote.checksum || !remote.version) return false;

      const localBuild = (typeof APP_BUILD_NUMBER === 'number')
        ? APP_BUILD_NUMBER
        : (Number(window.APP_BUILD_NUMBER) || 0);
      const localContentHash = (typeof APP_CONTENT_HASH === 'string')
        ? APP_CONTENT_HASH
        : (window.APP_CONTENT_HASH || '');

      const remoteBuild = Number(remote.build) || 0;
      if (remoteBuild > 0 && remoteBuild < localBuild) {
        return false; // Never downgrade below the running build number
      }

      if (remote.contentHash && localContentHash && remote.contentHash === localContentHash) {
        return false; // Running code is already byte-identical to remote OTA bundle
      }

      let targetBundle = null;
      try {
        if (typeof updater.list === 'function') {
          const listRes = await updater.list();
          const bundles = (listRes && Array.isArray(listRes.bundles)) ? listRes.bundles : [];
          targetBundle = bundles.find(b => b && b.version === remote.version && b.status !== 'error' && b.status !== 'deleted') || null;
        }
      } catch (e) {}

      if (!targetBundle || !targetBundle.id) {
        console.log(`[NativeBridge] Downloading OTA update ${remote.version}...`);
        targetBundle = await updater.download({
          url: remote.url,
          version: remote.version,
          checksum: remote.checksum
        });
      }

      if (targetBundle && targetBundle.id) {
        try {
          localStorage.setItem('showUp_ota_applied_checksum', remote.checksum);
          localStorage.setItem('showUp_ota_applied_version', remote.version);
        } catch (e) {}

        if (typeof updater.next === 'function') {
          await updater.next({ id: targetBundle.id }).catch(() => {});
        }

        if (!isWorkoutInProgress() && typeof updater.set === 'function') {
          console.log(`[NativeBridge] Applying OTA bundle ${remote.version} immediately...`);
          await updater.set({ id: targetBundle.id }).catch(() => {});
        } else {
          console.log(`[NativeBridge] Staged OTA bundle ${remote.version} for next launch.`);
        }
        return true;
      }
    } catch (err) {
      console.warn('[NativeBridge] OTA update check notice:', err);
    } finally {
      otaCheckInFlight = false;
    }
    return false;
  }

  function getGoogleAuthPlugin() {
    if (typeof window === 'undefined' || !window.Capacitor) return null;
    if (window.Capacitor.Plugins && window.Capacitor.Plugins.GoogleAuth) {
      return window.Capacitor.Plugins.GoogleAuth;
    }
    if (typeof window.Capacitor.registerPlugin === 'function') {
      return window.Capacitor.registerPlugin('GoogleAuth');
    }
    if (typeof window.Capacitor.nativePromise === 'function') {
      return {
        initialize: (opts) => window.Capacitor.nativePromise('GoogleAuth', 'initialize', opts || {}),
        signIn: (opts) => window.Capacitor.nativePromise('GoogleAuth', 'signIn', opts || {}),
        refresh: (opts) => window.Capacitor.nativePromise('GoogleAuth', 'refresh', opts || {}),
        signOut: (opts) => window.Capacitor.nativePromise('GoogleAuth', 'signOut', opts || {})
      };
    }
    return null;
  }

  // 1f. Perform Native Google Sign-In via ASWebAuthenticationSession / GIDSignIn / GoogleSignInClient
  async function signInNativeGoogle() {
    if (!isNative()) return null;
    const googleAuth = getGoogleAuthPlugin();
    if (!googleAuth || typeof googleAuth.signIn !== 'function') return null;

    const isIos = window.Capacitor.getPlatform?.() === 'ios';
    const clientId = isIos
      ? '115199141886-99m5rosha76ftskaeknj2e757mn0sb0t.apps.googleusercontent.com'
      : '489093591529-0cepullrdv1684c6e0p545850rocunfk.apps.googleusercontent.com';

    try {
      await googleAuth.initialize({
        clientId: clientId,
        serverClientId: '489093591529-0cepullrdv1684c6e0p545850rocunfk.apps.googleusercontent.com',
        scopes: ['profile', 'email', 'https://www.googleapis.com/auth/drive.file'],
        grantOfflineAccess: false
      });
    } catch (e) {}

    return await googleAuth.signIn();
  }

  async function refreshNativeGoogleToken() {
    if (!isNative()) return null;
    const googleAuth = getGoogleAuthPlugin();
    if (!googleAuth || typeof googleAuth.refresh !== 'function') return null;
    try {
      return await googleAuth.refresh();
    } catch (e) {
      return null;
    }
  }

  async function signOutNativeGoogle() {
    if (!isNative()) return;
    const googleAuth = getGoogleAuthPlugin();
    if (googleAuth && typeof googleAuth.signOut === 'function') {
      try {
        await googleAuth.signOut();
      } catch (e) {}
    }
  }

  // 2. Schedule Local Notification for Target Rest Recovery
  async function scheduleRestNotification(targetSeconds, exerciseName = '') {
    if (!isNative()) return;
    if (!window.Capacitor.Plugins || !window.Capacitor.Plugins.LocalNotifications) return;

    try {
      const atTime = new Date(Date.now() + (targetSeconds * 1000));
      const title = "Ready to Lift!";
      const body = exerciseName 
        ? `Target recovery reached (${targetSeconds}s). Ready for next set of ${exerciseName}!`
        : `Target rest of ${targetSeconds}s reached. You are fully recovered!`;

      await cancelRestNotification();

      await window.Capacitor.Plugins.LocalNotifications.schedule({
        notifications: [
          {
            id: REST_NOTIFICATION_ID,
            title: title,
            body: body,
            schedule: { at: atTime },
            sound: 'beep.wav',
            smallIcon: 'ic_stat_icon_config_sample',
            iconColor: '#10b981',
            actionTypeId: '',
            extra: { type: 'rest_timer' }
          }
        ]
      });
    } catch (err) {
      console.warn("[NativeBridge] Failed to schedule rest notification:", err);
    }
  }

  // 3. Cancel scheduled rest notification (when user starts set or resets timer early)
  async function cancelRestNotification() {
    if (!isNative()) return;
    if (!window.Capacitor.Plugins || !window.Capacitor.Plugins.LocalNotifications) return;

    try {
      await window.Capacitor.Plugins.LocalNotifications.cancel({
        notifications: [{ id: REST_NOTIFICATION_ID }]
      });
    } catch (err) {
      console.warn("[NativeBridge] Failed to cancel rest notification:", err);
    }
  }

  // 4. Native Haptics Trigger
  async function triggerNativeHaptic(type = 'light') {
    if (!isNative() || !window.Capacitor.Plugins || !window.Capacitor.Plugins.Haptics) {
      return false; // Not handled, fallback to web navigator.vibrate
    }

    try {
      const Haptics = window.Capacitor.Plugins.Haptics;
      switch (type) {
        case 'light':
          await Haptics.impact({ style: 'LIGHT' });
          break;
        case 'medium':
          await Haptics.impact({ style: 'MEDIUM' });
          break;
        case 'heavy':
          await Haptics.impact({ style: 'HEAVY' });
          break;
        case 'recovery':
          await Haptics.notification({ type: 'SUCCESS' });
          break;
        default:
          await Haptics.impact({ style: 'LIGHT' });
      }
      return true;
    } catch (e) {
      return false;
    }
  }

  // Expose global NativeBridge
  window.NativeBridge = {
    isNative: isNative,
    scheduleRestNotification: scheduleRestNotification,
    cancelRestNotification: cancelRestNotification,
    triggerNativeHaptic: triggerNativeHaptic,
    signInNativeGoogle: signInNativeGoogle,
    refreshNativeGoogleToken: refreshNativeGoogleToken,
    signOutNativeGoogle: signOutNativeGoogle,
    checkAndApplyOTAUpdate: checkAndApplyOTAUpdate
  };

  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible' && isNative()) {
      checkAndApplyOTAUpdate().catch(() => {});
    }
  });

  // Run on DOM ready, window load, deviceready, and short retry loop
  let initialized = false;
  function triggerInit() {
    if (initialized) return;
    if (isNative()) {
      initialized = true;
      initNativeBridge();
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', triggerInit);
  } else {
    triggerInit();
  }
  window.addEventListener('load', triggerInit);
  document.addEventListener('deviceready', triggerInit);

  // Short retry loop to catch asynchronous Capacitor script injection
  for (const delay of [60, 150, 300, 600, 1200]) {
    setTimeout(triggerInit, delay);
  }

})(window);
