/* ==========================================================================
   showUp History & Calendar Engine: Monthly Grids & "Showed Up" Rules
   ========================================================================== */

    function initDatePickerConstraints() {
      const todayISO = typeof getLocalDateKey === 'function' ? getLocalDateKey() : new Date().toISOString().slice(0, 10);
      const dateInput = document.getElementById('workout-date-picker');
      if (dateInput) {
        dateInput.max = todayISO;
        dateInput.value = todayISO;
      }
      selectedWorkoutDate = todayISO;
      updateTimezoneDisplay();
    }

    function handleDateChange(val) {
      const todayISO = typeof getLocalDateKey === 'function' ? getLocalDateKey() : new Date().toISOString().slice(0, 10);
      if (val > todayISO) {
        alert("Future dates beyond current day are not allowed.");
        const dateInput = document.getElementById('workout-date-picker');
        if (dateInput) dateInput.value = todayISO;
        selectedWorkoutDate = todayISO;
        document.getElementById('historical-mode-banner').classList.add('hidden');
        return;
      }
      selectedWorkoutDate = val;

      if (val !== todayISO) {
        document.getElementById('banner-date-label').innerText = val;
        document.getElementById('historical-mode-banner').classList.remove('hidden');
      } else {
        document.getElementById('historical-mode-banner').classList.add('hidden');
      }
    }

    function resetToTodayDate() {
      const todayISO = typeof getLocalDateKey === 'function' ? getLocalDateKey() : new Date().toISOString().slice(0, 10);
      const dateInput = document.getElementById('workout-date-picker');
      if (dateInput) dateInput.value = todayISO;
      selectedWorkoutDate = todayISO;
      document.getElementById('historical-mode-banner').classList.add('hidden');
    }

    function updateTimezoneDisplay() {
      const tzName = typeof getUserTimeZone === 'function' ? getUserTimeZone() : '';
      const tzEl = document.getElementById('user-timezone-display');
      const settingsTzEl = document.getElementById('settings-timezone-label');
      if (tzName) {
        let shortCode = '';
        try {
          shortCode = new Intl.DateTimeFormat('en-US', {
            timeZone: tzName,
            timeZoneName: 'short'
          }).formatToParts(new Date()).find(p => p.type === 'timeZoneName')?.value || '';
        } catch (e) {}

        const label = shortCode ? `${shortCode} (${tzName})` : tzName;
        if (tzEl) {
          tzEl.innerText = shortCode || tzName;
          tzEl.title = `Local Time Zone: ${tzName}`;
        }
        if (settingsTzEl) {
          settingsTzEl.innerText = label;
          settingsTzEl.title = `Active Time Zone: ${tzName}`;
        }
      }
    }



    function renderCalendar() {
      if (typeof AppStorage !== 'undefined' && typeof AppStorage.getAthleteWorkouts === 'function') {
        const fresh = AppStorage.getAthleteWorkouts();
        if (Array.isArray(fresh)) {
          completedWorkoutsHistory = fresh;
        }
      }

      const grid = document.getElementById('calendar-grid');
      const monthYearLabel = document.getElementById('calendar-month-year-label');
      if (!grid || !monthYearLabel) return;
      grid.innerHTML = '';

      const year = calendarDate.getFullYear();
      const month = calendarDate.getMonth();

      const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
      monthYearLabel.innerText = `${monthNames[month]} ${year}`;

      // Update streak badges in calendar view header
      if (typeof calcShowUpStreak === 'function') {
        const streak = calcShowUpStreak();
        const curStreakEl = document.getElementById('current-streak-val');
        if (curStreakEl) curStreakEl.innerText = `${streak} day${streak === 1 ? '' : 's'}`;
        const bestStreakEl = document.getElementById('best-streak-val');
        if (bestStreakEl) bestStreakEl.innerText = `${streak} days`;
      }

      // Week starts from Monday (M) and ends on Sunday (S)
      const dayNames = ["M", "T", "W", "T", "F", "S", "S"];
      const dayTitles = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
      dayNames.forEach((d, idx) => {
        grid.innerHTML += `<div class="text-slate-500 font-bold py-1" title="${dayTitles[idx]}">${d}</div>`;
      });

      // Shift first day offset: Monday is index 0, Sunday is index 6
      const firstDay = (new Date(year, month, 1).getDay() + 6) % 7;
      const daysInMonth = new Date(year, month + 1, 0).getDate();

      for (let i = 0; i < firstDay; i++) {
        grid.innerHTML += `<div></div>`;
      }

      for (let day = 1; day <= daysInMonth; day++) {
        const monthStr = String(month + 1).padStart(2, '0');
        const dayStr = String(day).padStart(2, '0');
        const dateKey = `${year}-${monthStr}-${dayStr}`;
        
        const isWorkedOut = completedWorkoutsHistory.some(item => (typeof item === 'string' ? item : item.date) === dateKey);

        grid.innerHTML += `
          <div onclick="${isWorkedOut ? `triggerHaptic('light'); openEditHistoricalWorkoutModal('${dateKey}')` : ''}"
               class="aspect-square flex items-center justify-center rounded-xl text-xs font-semibold cursor-pointer transition transform ${isWorkedOut ? 'bg-emerald-500 text-slate-950 font-black shadow-lg shadow-emerald-500/20 hover:scale-105 active:scale-95' : 'bg-slate-950 text-slate-600 border border-slate-800/80'}"
               title="${isWorkedOut ? `Completed workout on ${dateKey} (Click to Edit)` : dateKey}">
            ${day}
          </div>
        `;
      }
    }

    function renderMonthlyHistory() {
      if (typeof AppStorage !== 'undefined' && typeof AppStorage.getAthleteWorkouts === 'function') {
        const fresh = AppStorage.getAthleteWorkouts();
        if (Array.isArray(fresh)) {
          completedWorkoutsHistory = fresh;
        }
      }

      const container = document.getElementById('monthly-history-list');
      if (!container) return;
      const year = calendarDate.getFullYear();
      const monthStr = String(calendarDate.getMonth() + 1).padStart(2, '0');
      const prefix = `${year}-${monthStr}`;

      const monthlyEntries = completedWorkoutsHistory.filter(item => {
        const d = typeof item === 'string' ? item : item.date;
        return d && d.startsWith(prefix);
      });

      const countBadge = document.getElementById('monthly-count-badge');
      if (countBadge) countBadge.innerText = `${monthlyEntries.length} Workouts`;

      if (monthlyEntries.length === 0) {
        container.innerHTML = `<div class="text-center py-8 text-slate-600 text-xs italic">No workout history recorded for this month.</div>`;
        return;
      }

      container.innerHTML = monthlyEntries.map(w => {
        const dateStr = typeof w === 'string' ? w : w.date;
        const nameStr = typeof w === 'object' && w.workoutName ? w.workoutName : 'Workout Session';
        const notesStr = typeof w === 'object' && w.notes ? w.notes : '';
        const setsList = typeof w === 'object' && w.sets ? w.sets : [];
        const setsCount = setsList.length || '1+';
        const vol = typeof w === 'object' && w.totalVolume ? `${w.totalVolume.toLocaleString()} units` : 'Logged';
        const cals = typeof w === 'object' && w.caloriesBurned ? `${w.caloriesBurned} kcal` : '';

        return `
          <div class="bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden transition-all">
            <div onclick="triggerHaptic('light'); toggleWorkoutAccordion('${dateStr}')" class="p-3.5 flex items-center justify-between cursor-pointer hover:bg-slate-900/60 transition select-none">
              <div class="flex items-center gap-3">
                <i id="chevron-${dateStr}" class="fa-solid fa-chevron-right text-xs text-slate-500 transition-transform"></i>
                <div>
                  <div class="text-sm font-bold text-slate-100 flex items-center gap-2">
                    <i class="fa-solid fa-calendar-check text-emerald-400"></i>
                    <span>${nameStr}</span>
                    <span class="text-xs font-normal text-slate-400">(${dateStr})</span>
                    <!-- Pencil Icon: Quick Edit trigger beside workout title -->
                    <button onclick="event.stopPropagation(); triggerHaptic('medium'); openEditHistoricalWorkoutModal('${dateStr}')" class="text-slate-500 hover:text-amber-400 p-1 rounded-lg transition" title="Edit Workout (${dateStr})">
                      <i class="fa-solid fa-pencil text-[11px]"></i>
                    </button>
                  </div>
                  <div class="text-xs text-slate-400 mt-0.5 flex items-center gap-3">
                    <span>${setsCount} Sets</span>
                    <span class="text-slate-600">•</span>
                    <span class="text-emerald-400">${vol}</span>
                    ${cals ? `<span class="text-slate-600">•</span><span class="text-rose-400">${cals}</span>` : ''}
                  </div>
                </div>
              </div>

              <div class="flex items-center gap-1" onclick="event.stopPropagation()">
                <!-- Pencil Icon Action Button: Update historical workout with any details -->
                <button onclick="triggerHaptic('medium'); openEditHistoricalWorkoutModal('${dateStr}')" class="text-slate-500 hover:text-amber-400 p-2 transition rounded-xl hover:bg-slate-850" title="Edit Workout">
                  <i class="fa-solid fa-pencil text-xs"></i>
                </button>
                <button onclick="triggerHaptic('medium'); shareWorkoutToWhatsApp('${dateStr}')" class="text-slate-500 hover:text-emerald-400 p-2 transition" title="Share via WhatsApp">
                  <i class="fa-brands fa-whatsapp text-sm"></i>
                </button>
                <button onclick="triggerHaptic('light'); deleteHistoricalWorkout('${dateStr}')" class="text-slate-600 hover:text-rose-400 p-2 transition" title="Delete Workout">
                  <i class="fa-solid fa-trash-can text-xs"></i>
                </button>
              </div>
            </div>

            <div id="details-${dateStr}" class="hidden border-t border-slate-800/80 bg-slate-900/40 p-3 space-y-2">
              <div class="flex items-center justify-between pb-1">
                <span class="text-[10px] font-bold uppercase tracking-wider text-slate-500">Workout Details</span>
                <button onclick="triggerHaptic('medium'); openEditHistoricalWorkoutModal('${dateStr}')" class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/40 text-[11px] font-bold transition active:scale-95">
                  <i class="fa-solid fa-pencil text-[10px]"></i>
                  <span>Edit All Details</span>
                </button>
              </div>
              ${notesStr ? `<div class="text-xs text-slate-300 italic bg-slate-950/80 p-2 rounded-lg border border-slate-800 mb-2">Notes: "${notesStr}"</div>` : ''}
              ${typeof w === 'object' && w.totalWorkoutSeconds ? `
                <div class="flex items-center gap-2 flex-wrap text-[11px] font-mono bg-slate-950 p-2 rounded-xl border border-slate-800 text-slate-400">
                  <span class="text-cyan-400"><i class="fa-solid fa-stopwatch mr-1"></i>Total: ${w.totalWorkoutTimeFormatted || (w.totalWorkoutSeconds + 's')}</span>
                  <span class="text-slate-600">•</span>
                  <span class="text-emerald-400"><i class="fa-solid fa-bolt mr-1"></i>Active: ${w.totalActiveTimeFormatted || (w.totalActiveSeconds + 's')}</span>
                  <span class="text-slate-600">•</span>
                  <span class="text-amber-400"><i class="fa-solid fa-hourglass-half mr-1"></i>Rest: ${w.totalRestTimeFormatted || (w.totalRestSeconds + 's')}</span>
                </div>
              ` : ''}
              <div class="text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1">Logged Exercise Sets</div>
              ${setsList.length === 0 ? `
                <div class="text-xs text-slate-500 italic py-1">Basic summary log recorded (no detailed sets).</div>
              ` : setsList.map(s => `
                <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex items-center justify-between text-xs">
                  <div>
                    <div class="font-bold text-slate-200">${s.exerciseName}</div>
                    <div class="text-slate-400 gap-2 flex items-center mt-0.5 text-[11px]">
                      <span class="bg-slate-800 text-emerald-400 px-1.5 py-0.2 rounded-lg">${s.implement}</span>
                      ${s.implement === "Running" ? `<span>${s.runningDistance} mi | ${s.runningTime}${s.runningAvgHR ? ` | HR: ${s.runningAvgHR} avg` + (s.runningMaxHR ? ` / ${s.runningMaxHR} max` : '') : ''}</span>` :
                        s.implement === "Row Erg" ? `<span>${s.ergDistance}m | ${s.ergTime}</span>` :
                        s.implement === "Swimming" ? `<span>${s.swimDistance} yds | ${s.swimTime}</span>` :
                        ["Walking", "Hiking", "Biking"].includes(s.implement) ? `<span>${s.enduranceDistance} mi | ${s.enduranceTime}</span>` :
                        `<span><b class="text-slate-100">${s.weight}</b> lbs × <b class="text-slate-100">${s.reps}</b> reps</span>`}
                      <span class="text-slate-500">RPE ${s.rpe}</span>
                      ${s.setDuration ? `<span class="text-slate-400"><i class="fa-regular fa-clock mr-1 text-slate-500"></i>${typeof formatDurationSecs === 'function' ? formatDurationSecs(s.setDuration) : (s.setDuration + 's')}</span>` : ''}
                      ${s.restPeriod ? `<span class="text-emerald-400/80"><i class="fa-solid fa-hourglass-half mr-1 text-emerald-500"></i>Rest: ${typeof formatDurationSecs === 'function' ? formatDurationSecs(s.restPeriod) : (s.restPeriod + 's')}</span>` : ''}
                    </div>
                  </div>

                  <button onclick="triggerHaptic('medium'); openEditHistoricalWorkoutModal('${dateStr}')" class="text-slate-500 hover:text-amber-400 p-1.5 rounded-lg transition" title="Edit Workout / Set">
                    <i class="fa-solid fa-pencil text-xs"></i>
                  </button>
                </div>
              `).join('')}
            </div>
          </div>
        `;
      }).join('');
    }

    function toggleWorkoutAccordion(dateStr) {
      const detailsEl = document.getElementById(`details-${dateStr}`);
      const chevronEl = document.getElementById(`chevron-${dateStr}`);

      if (detailsEl.classList.contains('hidden')) {
        detailsEl.classList.remove('hidden');
        if (chevronEl) chevronEl.style.transform = "rotate(90deg)";
      } else {
        detailsEl.classList.add('hidden');
        if (chevronEl) chevronEl.style.transform = "rotate(0deg)";
      }
    }

    // ==========================================================================
    // Historical Workout Editor Engine (Pencil Icon & Comprehensive Updating)
    // ==========================================================================

    let currentEditingWorkoutOriginalDate = null;

    function openEditHistoricalWorkoutModal(dateStr) {
      if (!dateStr) return;
      currentEditingWorkoutOriginalDate = dateStr;

      const modal = document.getElementById('edit-historical-workout-modal');
      if (!modal) return;

      const rawWorkout = completedWorkoutsHistory.find(item => {
        const d = typeof item === 'string' ? item : item.date;
        return d === dateStr;
      });

      const workout = (typeof rawWorkout === 'object' && rawWorkout !== null)
        ? JSON.parse(JSON.stringify(rawWorkout))
        : {
            date: dateStr,
            workoutName: 'Workout Session',
            notes: '',
            caloriesBurned: 350,
            totalWorkoutSeconds: 2400,
            totalActiveSeconds: 1500,
            totalRestSeconds: 900,
            sets: []
          };

      // Populate core fields
      const dateInput = document.getElementById('edit-workout-date');
      const nameInput = document.getElementById('edit-workout-name');
      const notesInput = document.getElementById('edit-workout-notes');
      const calsInput = document.getElementById('edit-workout-calories');
      const durationInput = document.getElementById('edit-workout-duration');
      const activeInput = document.getElementById('edit-workout-active-time');
      const restInput = document.getElementById('edit-workout-rest-time');

      if (dateInput) dateInput.value = workout.date || dateStr;
      if (nameInput) nameInput.value = workout.workoutName || 'Workout Session';
      if (notesInput) notesInput.value = workout.notes || '';
      if (calsInput) calsInput.value = workout.caloriesBurned || workout.calories || 0;
      if (durationInput) durationInput.value = Math.round((workout.totalWorkoutSeconds || 1800) / 60);
      if (activeInput) activeInput.value = Math.round((workout.totalActiveSeconds || 1200) / 60);
      if (restInput) restInput.value = Math.round((workout.totalRestSeconds || 600) / 60);

      // Render editable sets
      renderEditWorkoutSets(workout.sets || []);

      modal.classList.remove('hidden');
    }

    function closeEditHistoricalWorkoutModal() {
      const modal = document.getElementById('edit-historical-workout-modal');
      if (modal) modal.classList.add('hidden');
      currentEditingWorkoutOriginalDate = null;
    }

    function renderEditWorkoutSets(sets) {
      const container = document.getElementById('edit-workout-sets-container');
      if (!container) return;

      if (!Array.isArray(sets) || sets.length === 0) {
        container.innerHTML = `
          <div id="edit-no-sets-prompt" class="p-4 rounded-xl bg-slate-950/80 border border-slate-800 text-center text-slate-500 text-xs italic">
            No detailed sets logged yet. Click "+ Add Set" below to add exercise sets with full metrics.
          </div>
        `;
        return;
      }

      container.innerHTML = sets.map((s, idx) => createEditSetRowMarkup(s, idx)).join('');
    }

    function createEditSetRowMarkup(s, idx) {
      const implement = s.implement || 'Barbell';
      const isRunning = implement === 'Running';
      const isCardio = ['Row Erg', 'Swimming', 'Walking', 'Hiking', 'Biking'].includes(implement);

      return `
        <div class="edit-set-row bg-slate-950 p-3 rounded-2xl border border-slate-800/90 space-y-2.5 relative" data-set-index="${idx}">
          <div class="flex items-center justify-between border-b border-slate-800/60 pb-1.5">
            <span class="text-[11px] font-mono font-bold text-emerald-400">Set #${idx + 1}</span>
            <button type="button" onclick="triggerHaptic('light'); removeEditSetRow(${idx})" class="text-slate-500 hover:text-rose-400 p-1 text-xs transition" title="Remove Set">
              <i class="fa-solid fa-trash-can"></i>
            </button>
          </div>

          <div class="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <div>
              <label class="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">Exercise</label>
              <input type="text" class="edit-set-exercise w-full bg-slate-900 border border-slate-700/80 rounded-xl px-2.5 py-1.5 text-xs text-slate-100 font-semibold focus:outline-none focus:border-emerald-500" value="${(typeof escapeHtml === 'function') ? escapeHtml(s.exerciseName || '') : (s.exerciseName || 'Exercise')}">
            </div>
            <div>
              <label class="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">Implement / Type</label>
              <select class="edit-set-implement w-full bg-slate-900 border border-slate-700/80 rounded-xl px-2.5 py-1.5 text-xs text-slate-100 font-semibold focus:outline-none focus:border-emerald-500" onchange="handleEditImplementChange(this)">
                <option value="Barbell" ${implement === 'Barbell' ? 'selected' : ''}>Barbell</option>
                <option value="Dumbbell" ${implement === 'Dumbbell' ? 'selected' : ''}>Dumbbell</option>
                <option value="Kettlebell" ${implement === 'Kettlebell' ? 'selected' : ''}>Kettlebell</option>
                <option value="Machine" ${implement === 'Machine' ? 'selected' : ''}>Machine</option>
                <option value="Cable" ${implement === 'Cable' ? 'selected' : ''}>Cable</option>
                <option value="Bodyweight" ${implement === 'Bodyweight' ? 'selected' : ''}>Bodyweight</option>
                <option value="Running" ${implement === 'Running' ? 'selected' : ''}>Running</option>
                <option value="Row Erg" ${implement === 'Row Erg' ? 'selected' : ''}>Row Erg</option>
                <option value="Swimming" ${implement === 'Swimming' ? 'selected' : ''}>Swimming</option>
                <option value="Walking" ${implement === 'Walking' ? 'selected' : ''}>Walking</option>
                <option value="Biking" ${implement === 'Biking' ? 'selected' : ''}>Biking</option>
              </select>
            </div>
          </div>

          <!-- Dynamic Metrics Grid -->
          <div class="edit-set-metrics-resistance grid grid-cols-3 gap-2 ${isRunning || isCardio ? 'hidden' : ''}">
            <div>
              <label class="block text-[10px] text-slate-400 mb-0.5">Weight (lbs)</label>
              <input type="number" step="0.5" class="edit-set-weight w-full bg-slate-900 border border-slate-800 rounded-xl px-2 py-1 text-xs text-slate-100 font-mono font-bold" value="${s.weight || 0}">
            </div>
            <div>
              <label class="block text-[10px] text-slate-400 mb-0.5">Reps</label>
              <input type="number" step="1" class="edit-set-reps w-full bg-slate-900 border border-slate-800 rounded-xl px-2 py-1 text-xs text-slate-100 font-mono font-bold" value="${s.reps || 10}">
            </div>
            <div>
              <label class="block text-[10px] text-slate-400 mb-0.5">RPE (1-10)</label>
              <input type="number" step="0.5" min="1" max="10" class="edit-set-rpe w-full bg-slate-900 border border-slate-800 rounded-xl px-2 py-1 text-xs text-slate-100 font-mono font-bold" value="${s.rpe || 8}">
            </div>
          </div>

          <div class="edit-set-metrics-endurance grid grid-cols-2 sm:grid-cols-4 gap-2 ${isRunning || isCardio ? '' : 'hidden'}">
            <div>
              <label class="block text-[10px] text-slate-400 mb-0.5">Distance</label>
              <input type="number" step="0.01" class="edit-set-distance w-full bg-slate-900 border border-slate-800 rounded-xl px-2 py-1 text-xs text-slate-100 font-mono font-bold" value="${s.runningDistance || s.enduranceDistance || s.ergDistance || s.swimDistance || 1.0}">
            </div>
            <div>
              <label class="block text-[10px] text-slate-400 mb-0.5">Time (hh:mm:ss)</label>
              <input type="text" class="edit-set-time w-full bg-slate-900 border border-slate-800 rounded-xl px-2 py-1 text-xs text-slate-100 font-mono font-bold" value="${s.runningTime || s.enduranceTime || s.ergTime || s.swimTime || '00:20:00'}">
            </div>
            <div>
              <label class="block text-[10px] text-slate-400 mb-0.5">Avg HR (bpm)</label>
              <input type="number" class="edit-set-avg-hr w-full bg-slate-900 border border-slate-800 rounded-xl px-2 py-1 text-xs text-slate-100 font-mono font-bold" value="${s.runningAvgHR || s.avgHR || ''}">
            </div>
            <div>
              <label class="block text-[10px] text-slate-400 mb-0.5">Max HR (bpm)</label>
              <input type="number" class="edit-set-max-hr w-full bg-slate-900 border border-slate-800 rounded-xl px-2 py-1 text-xs text-slate-100 font-mono font-bold" value="${s.runningMaxHR || s.maxHR || ''}">
            </div>
          </div>
        </div>
      `;
    }

    function handleEditImplementChange(selectEl) {
      const row = selectEl.closest('.edit-set-row');
      if (!row) return;
      const implement = selectEl.value;
      const isCardio = ['Running', 'Row Erg', 'Swimming', 'Walking', 'Hiking', 'Biking'].includes(implement);
      const resPanel = row.querySelector('.edit-set-metrics-resistance');
      const endPanel = row.querySelector('.edit-set-metrics-endurance');

      if (isCardio) {
        if (resPanel) resPanel.classList.add('hidden');
        if (endPanel) endPanel.classList.remove('hidden');
      } else {
        if (resPanel) resPanel.classList.remove('hidden');
        if (endPanel) endPanel.classList.add('hidden');
      }
    }

    function addSetToEditHistoricalWorkout() {
      const container = document.getElementById('edit-workout-sets-container');
      if (!container) return;
      const noSetsPrompt = document.getElementById('edit-no-sets-prompt');
      if (noSetsPrompt) noSetsPrompt.remove();

      const currentCount = container.querySelectorAll('.edit-set-row').length;
      const newSetObj = {
        id: Date.now() + Math.floor(Math.random() * 1000),
        exerciseName: 'Exercise',
        implement: 'Barbell',
        weight: 135,
        reps: 10,
        rpe: 8,
        setDuration: 45,
        restPeriod: 90
      };

      const wrapper = document.createElement('div');
      wrapper.innerHTML = createEditSetRowMarkup(newSetObj, currentCount);
      container.appendChild(wrapper.firstElementChild);
    }

    function removeEditSetRow(idx) {
      const container = document.getElementById('edit-workout-sets-container');
      if (!container) return;
      const rows = container.querySelectorAll('.edit-set-row');
      if (rows[idx]) {
        rows[idx].remove();
      }
      // Re-index remaining rows
      const remaining = container.querySelectorAll('.edit-set-row');
      remaining.forEach((r, i) => {
        r.dataset.setIndex = i;
        const badge = r.querySelector('.text-emerald-400');
        if (badge) badge.innerText = `Set #${i + 1}`;
      });
      if (remaining.length === 0) {
        container.innerHTML = `
          <div id="edit-no-sets-prompt" class="p-4 rounded-xl bg-slate-950/80 border border-slate-800 text-center text-slate-500 text-xs italic">
            No detailed sets logged yet. Click "+ Add Set" below to add exercise sets with full metrics.
          </div>
        `;
      }
    }

    function saveHistoricalWorkoutChanges() {
      if (!currentEditingWorkoutOriginalDate) return;
      const origDate = currentEditingWorkoutOriginalDate;

      const dateInput = document.getElementById('edit-workout-date');
      const nameInput = document.getElementById('edit-workout-name');
      const notesInput = document.getElementById('edit-workout-notes');
      const calsInput = document.getElementById('edit-workout-calories');
      const durationInput = document.getElementById('edit-workout-duration');
      const activeInput = document.getElementById('edit-workout-active-time');
      const restInput = document.getElementById('edit-workout-rest-time');

      const targetDate = (dateInput && dateInput.value.trim()) ? dateInput.value.trim() : origDate;
      const workoutName = (nameInput && nameInput.value.trim()) ? nameInput.value.trim() : 'Workout Session';
      const notes = notesInput ? notesInput.value.trim() : '';
      const caloriesBurned = calsInput ? (parseFloat(calsInput.value) || 0) : 0;
      const totalMinutes = durationInput ? (parseFloat(durationInput.value) || 30) : 30;
      const activeMinutes = activeInput ? (parseFloat(activeInput.value) || 20) : 20;
      const restMinutes = restInput ? (parseFloat(restInput.value) || 10) : 10;

      const totalWorkoutSeconds = Math.round(totalMinutes * 60);
      const totalActiveSeconds = Math.round(activeMinutes * 60);
      const totalRestSeconds = Math.round(restMinutes * 60);

      // Collect sets from DOM
      const rows = document.querySelectorAll('#edit-workout-sets-container .edit-set-row');
      const updatedSets = [];
      let totalVolume = 0;
      let totalDistance = 0;
      let runningSeconds = 0;
      let maxHR = 0;
      let avgHRSum = 0;
      let hrCount = 0;

      rows.forEach((r, idx) => {
        const exName = r.querySelector('.edit-set-exercise')?.value.trim() || `Set ${idx + 1}`;
        const implement = r.querySelector('.edit-set-implement')?.value || 'Barbell';
        const isCardio = ['Running', 'Row Erg', 'Swimming', 'Walking', 'Hiking', 'Biking'].includes(implement);

        const setObj = {
          id: Date.now() + idx,
          exerciseName: exName,
          implement: implement
        };

        if (isCardio) {
          const dist = parseFloat(r.querySelector('.edit-set-distance')?.value) || 1.0;
          const timeStr = r.querySelector('.edit-set-time')?.value.trim() || '00:20:00';
          const avgHR = parseInt(r.querySelector('.edit-set-avg-hr')?.value) || null;
          const mHR = parseInt(r.querySelector('.edit-set-max-hr')?.value) || null;

          if (implement === 'Running') {
            setObj.runningDistance = dist;
            setObj.runningTime = timeStr;
            setObj.runningAvgHR = avgHR;
            setObj.runningMaxHR = mHR;
            totalDistance += dist;
            if (avgHR) { avgHRSum += avgHR; hrCount++; }
            if (mHR && mHR > maxHR) maxHR = mHR;
          } else if (implement === 'Row Erg') {
            setObj.ergDistance = dist;
            setObj.ergTime = timeStr;
          } else if (implement === 'Swimming') {
            setObj.swimDistance = dist;
            setObj.swimTime = timeStr;
          } else {
            setObj.enduranceDistance = dist;
            setObj.enduranceTime = timeStr;
          }
        } else {
          const w = parseFloat(r.querySelector('.edit-set-weight')?.value) || 0;
          const reps = parseInt(r.querySelector('.edit-set-reps')?.value) || 0;
          const rpe = parseFloat(r.querySelector('.edit-set-rpe')?.value) || 8;
          setObj.weight = w;
          setObj.reps = reps;
          setObj.rpe = rpe;
          totalVolume += (w * reps);
        }

        updatedSets.push(setObj);
      });

      // Find original workout to preserve auxiliary metadata (e.g. photos, squad sync)
      const existingIdx = completedWorkoutsHistory.findIndex(item => {
        const d = typeof item === 'string' ? item : item.date;
        return d === origDate;
      });
      const originalObj = existingIdx !== -1 && typeof completedWorkoutsHistory[existingIdx] === 'object'
        ? completedWorkoutsHistory[existingIdx]
        : {};

      const updatedWorkout = {
        ...originalObj,
        id: originalObj.id || ('workout_' + Date.now()),
        date: targetDate,
        completedDate: targetDate,
        completed: true,
        workoutName: workoutName,
        notes: notes,
        caloriesBurned: caloriesBurned,
        calories: caloriesBurned,
        totalWorkoutSeconds: totalWorkoutSeconds,
        totalWorkoutTimeFormatted: typeof formatDurationSecs === 'function' ? formatDurationSecs(totalWorkoutSeconds) : `${totalMinutes}m`,
        totalActiveSeconds: totalActiveSeconds,
        totalActiveTimeFormatted: typeof formatDurationSecs === 'function' ? formatDurationSecs(totalActiveSeconds) : `${activeMinutes}m`,
        totalRestSeconds: totalRestSeconds,
        totalRestTimeFormatted: typeof formatDurationSecs === 'function' ? formatDurationSecs(totalRestSeconds) : `${restMinutes}m`,
        totalVolume: totalVolume,
        sets: updatedSets,
        lastModified: new Date().toISOString()
      };

      if (totalDistance > 0) {
        updatedWorkout.runningMetrics = {
          totalDistance: totalDistance,
          avgHR: hrCount > 0 ? Math.round(avgHRSum / hrCount) : null,
          maxHR: maxHR > 0 ? maxHR : null
        };
      }

      // Persist across AppStorage and in-memory caches
      if (typeof AppStorage !== 'undefined' && typeof AppStorage.updateWorkout === 'function') {
        AppStorage.updateWorkout(origDate, updatedWorkout);
      } else {
        if (origDate !== targetDate) {
          completedWorkoutsHistory = completedWorkoutsHistory.filter(item => (typeof item === 'string' ? item : item.date) !== origDate);
        }
        const matchIdx = completedWorkoutsHistory.findIndex(item => (typeof item === 'string' ? item : item.date) === targetDate);
        if (matchIdx !== -1) {
          completedWorkoutsHistory[matchIdx] = updatedWorkout;
        } else {
          completedWorkoutsHistory.push(updatedWorkout);
        }
        localStorage.setItem('showUp_synced_workouts', JSON.stringify(completedWorkoutsHistory));
      }

      // Sync views
      renderCalendar();
      renderMonthlyHistory();
      if (typeof renderHomeTab === 'function') renderHomeTab();
      if (typeof renderHeatMap === 'function') renderHeatMap();
      if (typeof updateGlobalStatsUI === 'function') updateGlobalStatsUI();

      if (googleAccessToken && typeof syncToGoogleDrive === 'function') {
        syncToGoogleDrive();
      }

      closeEditHistoricalWorkoutModal();

      if (typeof showToast === 'function') {
        showToast(`Workout for ${targetDate} updated successfully!`, 'success');
      }
    }

    function deleteHistoricalWorkout(dateStr) {
      if (typeof showAppConfirm === 'function') {
        showAppConfirm({
          title: "Delete Workout Entry?",
          message: `Are you sure you want to delete the workout entry for ${dateStr}? This action cannot be undone.`,
          confirmText: "Delete Entry",
          cancelText: "Keep Entry",
          type: "danger",
          icon: "fa-solid fa-trash-can",
          btnIcon: "fa-solid fa-trash-can"
        }).then((confirmed) => {
          if (confirmed) {
            executeDeleteHistoricalWorkout(dateStr);
          }
        });
        return;
      }
      if (!confirm(`Are you sure you want to delete the workout entry for ${dateStr}?`)) return;
      executeDeleteHistoricalWorkout(dateStr);
    }

    function executeDeleteHistoricalWorkout(dateStr) {

      if (typeof AppStorage !== 'undefined' && typeof AppStorage.deleteWorkout === 'function') {
        AppStorage.deleteWorkout(dateStr);
      } else {
        completedWorkoutsHistory = completedWorkoutsHistory.filter(item => (typeof item === 'string' ? item : item.date) !== dateStr);
        localStorage.setItem('showUp_synced_workouts', JSON.stringify(completedWorkoutsHistory));
      }
      renderCalendar();
      renderMonthlyHistory();
      if (typeof renderHomeTab === 'function') {
        renderHomeTab();
      }

      if (googleAccessToken) {
        syncToGoogleDrive();
      }
    }

    function navigateCalendarMonth(delta) {
      calendarDate.setMonth(calendarDate.getMonth() + delta);
      renderCalendar();
      renderMonthlyHistory();
    }

    // ==========================================================================
    // Home Section Engine: Weekly Positive Outlook & Daily Congratulation
    // ==========================================================================

    function getWeekWorkoutBounds(refDate = new Date()) {
      const d = new Date(refDate);
      const day = d.getDay(); // 0 is Sun, 1 is Mon...
      const diffToMonday = (day + 6) % 7; // days since Monday
      const monday = new Date(d);
      monday.setDate(d.getDate() - diffToMonday);
      monday.setHours(0, 0, 0, 0);

      const days = [];
      const dayNames = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
      const dayInitials = ["M", "T", "W", "T", "F", "S", "S"];

      for (let i = 0; i < 7; i++) {
        const cur = new Date(monday);
        cur.setDate(monday.getDate() + i);
        const y = cur.getFullYear();
        const m = String(cur.getMonth() + 1).padStart(2, '0');
        const dayNum = String(cur.getDate()).padStart(2, '0');
        const dateKey = `${y}-${m}-${dayNum}`;
        days.push({
          dateKey,
          dayNameShort: dayNames[i],
          dayInitial: dayInitials[i],
          dayNumber: cur.getDate()
        });
      }

      const sunday = new Date(monday);
      sunday.setDate(monday.getDate() + 6);
      sunday.setHours(23, 59, 59, 999);

      return {
        monday,
        sunday,
        days,
        startDateKey: days[0].dateKey,
        endDateKey: days[6].dateKey
      };
    }

    function calcShowUpStreak() {
      if (!Array.isArray(completedWorkoutsHistory) || completedWorkoutsHistory.length === 0) return 0;
      const dates = Array.from(new Set(completedWorkoutsHistory.map(w => typeof w === 'string' ? w : w.date).filter(Boolean))).sort().reverse();
      if (dates.length === 0) return 0;

      const todayLocal = typeof getLocalDateKey === 'function' ? getLocalDateKey() : new Date().toISOString().slice(0, 10);

      const yest = new Date();
      yest.setDate(yest.getDate() - 1);
      const yestLocal = typeof getLocalDateKey === 'function' ? getLocalDateKey(yest) : yest.toISOString().slice(0, 10);

      const mostRecent = dates[0];
      if (mostRecent !== todayLocal && mostRecent !== yestLocal) {
        return 0;
      }

      let streak = 0;
      let checkDate = new Date(mostRecent + 'T12:00:00');
      for (let i = 0; i < dates.length; i++) {
        const expected = typeof getLocalDateKey === 'function' ? getLocalDateKey(checkDate) : checkDate.toISOString().slice(0, 10);
        if (dates.includes(expected)) {
          streak++;
          checkDate.setDate(checkDate.getDate() - 1);
        } else {
          break;
        }
      }
      return streak;
    }

    function getWeekWorkoutStats(refDate = new Date()) {
      const bounds = getWeekWorkoutBounds(refDate);
      const todayKey = typeof getLocalDateKey === 'function' ? getLocalDateKey(refDate) : new Date().toISOString().slice(0, 10);
      const todayLocal = todayKey;

      const weekDateKeys = new Set(bounds.days.map(d => d.dateKey));
      const weekWorkouts = completedWorkoutsHistory.filter(w => {
        const d = typeof w === 'string' ? w : w.date;
        return weekDateKeys.has(d);
      });

      const workoutDatesThisWeek = new Set(weekWorkouts.map(w => typeof w === 'string' ? w : w.date));
      const daysCount = workoutDatesThisWeek.size;

      let weekVolume = 0;
      let weekSetsCount = 0;
      let weekCalories = 0;

      weekWorkouts.forEach(w => {
        if (typeof w === 'object') {
          if (w.totalVolume) weekVolume += w.totalVolume;
          if (Array.isArray(w.sets)) weekSetsCount += w.sets.length;
          if (w.caloriesBurned) weekCalories += w.caloriesBurned;
        }
      });

      const streak = calcShowUpStreak();

      // Week date range formatted string (e.g. "Oct 12 – Oct 18")
      const monthNamesShort = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
      const monMonth = monthNamesShort[bounds.monday.getMonth()];
      const sunMonth = monthNamesShort[bounds.sunday.getMonth()];
      const rangeLabel = (monMonth === sunMonth) 
        ? `${monMonth} ${bounds.monday.getDate()} – ${bounds.sunday.getDate()}`
        : `${monMonth} ${bounds.monday.getDate()} – ${sunMonth} ${bounds.sunday.getDate()}`;

      // Detailed days list with workout status
      const daysWithStatus = bounds.days.map(d => {
        const hasWorkout = workoutDatesThisWeek.has(d.dateKey);
        const isToday = (d.dateKey === todayKey || d.dateKey === todayLocal);
        return {
          ...d,
          hasWorkout,
          isToday
        };
      });

      // Positive celebration outlook tier based on week progress
      let outlookTier = 'fresh';
      let outlookHeadline = 'A fresh week full of potential!';
      let outlookMessage = 'Lock in your mindset and show up whenever you are ready.';
      let outlookBadge = 'Fresh Week';
      let outlookIcon = 'fa-seedling text-emerald-400';

      if (daysCount >= 4) {
        outlookTier = 'champion';
        outlookHeadline = "Outstanding dedication! Dominating this week.";
        outlookMessage = `${daysCount} workouts • ${weekVolume.toLocaleString()} lbs • ${weekSetsCount} sets. Elite focus!`;
        outlookBadge = 'Unstoppable Flow';
        outlookIcon = 'fa-crown text-amber-400';
      } else if (daysCount >= 2) {
        outlookTier = 'momentum';
        outlookHeadline = "Great consistency! Weekly momentum building strong.";
        outlookMessage = `${daysCount} solid sessions locked in. Effort is compounding!`;
        outlookBadge = 'Strong Momentum';
        outlookIcon = 'fa-fire text-amber-400';
      } else if (daysCount === 1) {
        outlookTier = 'starting';
        outlookHeadline = "On the board for this week!";
        outlookMessage = "First workout crushed. Keep the momentum rolling!";
        outlookBadge = 'On The Board';
        outlookIcon = 'fa-bolt text-emerald-400';
      }

      return {
        bounds,
        rangeLabel,
        days: daysWithStatus,
        daysCount,
        weekVolume,
        weekSetsCount,
        weekCalories,
        streak,
        outlookTier,
        outlookHeadline,
        outlookMessage,
        outlookBadge,
        outlookIcon
      };
    }

    function getDailyWorkoutCongratulation() {
      const todayKey = typeof getLocalDateKey === 'function' ? getLocalDateKey() : new Date().toISOString().slice(0, 10);
      const todayLocal = todayKey;

      const todayWorkout = completedWorkoutsHistory.find(w => {
        const d = typeof w === 'string' ? w : w.date;
        return d === todayKey || d === todayLocal;
      });

      if (!todayWorkout) {
        return {
          completed: false,
          kicker: "Daily Opportunity",
          headline: "Ready to get moving today?",
          message: "Even 15 minutes of pushups, lifting, or a brisk walk keeps your weekly consistency alive. Let's make today count!",
          todayKey
        };
      }

      const workoutName = (typeof todayWorkout === 'object' && todayWorkout.workoutName) ? todayWorkout.workoutName : "Workout Session";
      const setsCount = (typeof todayWorkout === 'object' && Array.isArray(todayWorkout.sets)) ? todayWorkout.sets.length : (todayWorkout.totalSets || 1);
      const vol = (typeof todayWorkout === 'object' && todayWorkout.totalVolume) ? `${todayWorkout.totalVolume.toLocaleString()} lbs` : null;
      const cals = (typeof todayWorkout === 'object' && todayWorkout.caloriesBurned) ? `${todayWorkout.caloriesBurned} kcal` : null;
      const timeStr = (typeof todayWorkout === 'object' && todayWorkout.totalWorkoutTimeFormatted) ? todayWorkout.totalWorkoutTimeFormatted : (todayWorkout.durationFormatted || null);

      // Casual congratulatory messages
      const casualMessages = [
        {
          kicker: "Hell yeah! 💥",
          headline: "You showed up today and put in the work.",
          subtext: "Consistency wins every time. Sweat equity in the bank!"
        },
        {
          kicker: "Boom! 🏆",
          headline: "Today's workout is crushed and in the books.",
          subtext: "Effort logged. Future self is thanking you."
        },
        {
          kicker: "Massive respect! 💪",
          headline: "Discipline beats motivation every day of the week.",
          subtext: "Rest up, champion — earned every bit of today."
        },
        {
          kicker: "Work done! ⚡",
          headline: "Today's session is locked in.",
          subtext: "Great energy and execution on your journey."
        }
      ];

      // Pick message deterministically based on workout name & date
      const seed = Math.abs((workoutName.length + (new Date().getDate())) % casualMessages.length);
      const selected = casualMessages[seed];

      return {
        completed: true,
        workout: todayWorkout,
        workoutName,
        setsCount,
        vol,
        cals,
        timeStr,
        kicker: selected.kicker,
        headline: selected.headline,
        subtext: selected.subtext,
        completedDate: (typeof todayWorkout === 'object' && todayWorkout.date) ? todayWorkout.date : todayKey,
        todayKey
      };
    }

    function renderHomeTab() {
      const container = document.getElementById('tab-home-view');
      if (!container) return;

      const user = (typeof getAppUser === 'function') ? getAppUser() : { name: 'Athlete', rawName: 'Athlete' };
      const athleteName = user.rawName || user.name || 'Athlete';

      const hour = new Date().getHours();
      let timeOfDayGreeting = 'Good morning';
      if (hour >= 12 && hour < 17) timeOfDayGreeting = 'Good afternoon';
      else if (hour >= 17) timeOfDayGreeting = 'Good evening';

      const weekStats = getWeekWorkoutStats();
      const dailyStatus = getDailyWorkoutCongratulation();

      // Update greeting card
      const greetingEl = document.getElementById('home-greeting-headline');
      if (greetingEl) {
        const safeName = (typeof escapeHtml === 'function') ? escapeHtml(athleteName) : athleteName;
        greetingEl.innerHTML = `${timeOfDayGreeting}, ${safeName} 👋`;
      }
      const streakCountEl = document.getElementById('home-streak-count');
      if (streakCountEl) {
        streakCountEl.innerText = `${weekStats.streak} Day Streak`;
      }

      // Update best-streak-val in calendar card if present
      const bestStreakEl = document.getElementById('best-streak-val');
      if (bestStreakEl) {
        bestStreakEl.innerText = `${weekStats.streak} days`;
      }

      // 1. Render Today's Casual Congratulation (Requirement 2: inside This Week's Outlook)
      const todayCard = document.getElementById('home-today-status-card');
      if (todayCard) {
        if (dailyStatus.completed) {
          todayCard.classList.remove('hidden');
          todayCard.className = "hero-victory-card rounded-2xl p-4 border border-emerald-500/40 shadow-xl space-y-3 transition-all";
          const safeKicker = (typeof escapeHtml === 'function') ? escapeHtml(dailyStatus.kicker) : dailyStatus.kicker;
          const safeHeadline = (typeof escapeHtml === 'function') ? escapeHtml(dailyStatus.headline) : dailyStatus.headline;
          const safeSubtext = (typeof escapeHtml === 'function') ? escapeHtml(dailyStatus.subtext) : dailyStatus.subtext;
          const safeWorkoutName = (typeof escapeHtml === 'function') ? escapeHtml(dailyStatus.workoutName) : dailyStatus.workoutName;
          const completedDate = dailyStatus.completedDate || (typeof getEasternTimeDateKey === 'function' ? getEasternTimeDateKey() : (typeof getLocalDateKey === 'function' ? getLocalDateKey() : new Date().toISOString().slice(0, 10)));

          const stat2Label = dailyStatus.vol ? 'Volume' : (dailyStatus.cals ? 'Energy' : 'Activity');
          const stat2Val = dailyStatus.vol || dailyStatus.cals || 'Completed';
          const stat3Label = dailyStatus.timeStr ? 'Duration' : (dailyStatus.cals && dailyStatus.vol ? 'Calories' : 'Status');
          const stat3Val = dailyStatus.timeStr || dailyStatus.cals || 'Logged';

          todayCard.innerHTML = `
            <div class="flex items-center justify-between gap-2 border-b border-emerald-500/20 pb-2">
              <span class="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm">
                <i class="fa-solid fa-trophy text-emerald-400"></i> ${safeKicker}
              </span>
              <div class="flex items-center gap-1.5">
                <span class="text-xs font-bold text-emerald-400 font-mono">${safeWorkoutName}</span>
                <button type="button" onclick="triggerHaptic('medium'); openEditHistoricalWorkoutModal('${completedDate}')" class="text-slate-400 hover:text-amber-400 p-1 rounded-lg transition" title="Edit Today's Workout">
                  <i class="fa-solid fa-pencil text-xs"></i>
                </button>
              </div>
            </div>
            <div class="space-y-0.5">
              <h3 class="text-sm font-black text-slate-100">
                ${safeHeadline}
              </h3>
              <p class="text-xs text-emerald-400/90 font-medium">
                ${safeSubtext}
              </p>
            </div>
            <div class="grid grid-cols-3 gap-2 pt-0.5">
              <div class="bg-slate-950/70 border border-emerald-500/20 rounded-xl py-2 px-1.5 text-center">
                <span class="text-[9px] uppercase font-bold text-slate-400 block tracking-wider">Sets</span>
                <span class="text-xs sm:text-sm font-black text-emerald-400 font-mono">${dailyStatus.setsCount}</span>
              </div>
              <div class="bg-slate-950/70 border border-emerald-500/20 rounded-xl py-2 px-1.5 text-center">
                <span class="text-[9px] uppercase font-bold text-slate-400 block tracking-wider">${stat2Label}</span>
                <span class="text-xs sm:text-sm font-black text-slate-100 font-mono truncate block">${stat2Val}</span>
              </div>
              <div class="bg-slate-950/70 border border-emerald-500/20 rounded-xl py-2 px-1.5 text-center">
                <span class="text-[9px] uppercase font-bold text-slate-400 block tracking-wider">${stat3Label}</span>
                <span class="text-xs sm:text-sm font-black text-slate-100 font-mono truncate block">${stat3Val}</span>
              </div>
            </div>
          `;
        } else {
          todayCard.classList.add('hidden');
          todayCard.innerHTML = '';
        }
      }

      // 2. Render Weekly Range & Count Badge
      const rangeLabelEl = document.getElementById('home-week-range-label');
      if (rangeLabelEl) rangeLabelEl.innerText = weekStats.rangeLabel;
      const weekCountBadgeEl = document.getElementById('home-week-count-badge');
      if (weekCountBadgeEl) weekCountBadgeEl.innerText = `${weekStats.daysCount} / 7 Days Showed Up`;

      // 3. Render 7-day visual pills (Monday to Sunday) - days when showed up are filled with the theme color
      const pillsContainer = document.getElementById('home-week-pills-container');
      if (pillsContainer) {
        pillsContainer.innerHTML = weekStats.days.map(d => {
          if (d.hasWorkout) {
            return `
              <div class="flex flex-col items-center justify-center py-2.5 px-1 rounded-2xl transition-all shadow-md ${d.isToday ? 'ring-2 ring-white/80' : ''}"
                   style="background-color: var(--m3-primary); color: var(--m3-onPrimary); border: 1px solid var(--m3-primary); box-shadow: 0 4px 14px -2px color-mix(in srgb, var(--m3-primary) 40%, transparent);"
                   title="${d.dayNameShort}: Showed Up!">
                <span class="text-[10px] font-black uppercase tracking-wider opacity-90">${d.dayInitial}</span>
                <span class="text-xs sm:text-sm font-black font-mono my-0.5">${d.dayNumber}</span>
                <i class="fa-solid fa-circle-check text-xs mt-0.5"></i>
              </div>
            `;
          } else if (d.isToday) {
            return `
              <div class="flex flex-col items-center justify-center py-2.5 px-1 rounded-2xl bg-slate-900 border border-slate-700 text-slate-200 ring-2 ring-emerald-400/80 shadow-md"
                   title="${d.dayNameShort}: Today">
                <span class="text-[10px] font-bold uppercase text-emerald-400">${d.dayInitial}</span>
                <span class="text-xs sm:text-sm font-black font-mono my-0.5">${d.dayNumber}</span>
                <span class="text-[9px] font-semibold text-slate-400">Today</span>
              </div>
            `;
          } else {
            return `
              <div class="flex flex-col items-center justify-center py-2.5 px-1 rounded-2xl bg-slate-950/80 border border-slate-800/80 text-slate-500"
                   title="${d.dayNameShort}: Rest or upcoming">
                <span class="text-[10px] font-bold uppercase">${d.dayInitial}</span>
                <span class="text-xs sm:text-sm font-bold font-mono my-0.5 text-slate-400">${d.dayNumber}</span>
                <span class="w-1.5 h-1.5 rounded-full bg-slate-800 mt-1"></span>
              </div>
            `;
          }
        }).join('');
      }

      // 4. Render Celebration Banner (Requirement 1)
      const bannerEl = document.getElementById('home-week-celebration-banner');
      if (bannerEl) {
        const safeHeadline = (typeof escapeHtml === 'function') ? escapeHtml(weekStats.outlookHeadline) : weekStats.outlookHeadline;
        const safeMessage = (typeof escapeHtml === 'function') ? escapeHtml(weekStats.outlookMessage) : weekStats.outlookMessage;

        if (dailyStatus.completed) {
          // When workout is completed today, keep weekly banner compact so today's victory card shines!
          bannerEl.className = "flex items-center justify-between px-3.5 py-2 rounded-xl bg-slate-950/60 border border-slate-800/80 text-xs transition-all";
          bannerEl.innerHTML = `
            <span class="text-xs font-bold flex items-center gap-2 text-slate-200">
              <i class="fa-solid ${weekStats.outlookIcon}"></i>
              ${safeHeadline}
            </span>
            <span class="text-[11px] font-semibold text-emerald-400 font-mono tracking-tight">${weekStats.daysCount} of 7 Logged</span>
          `;
        } else {
          const isHighTier = weekStats.daysCount >= 2;
          bannerEl.className = isHighTier
            ? "rounded-2xl p-3.5 bg-gradient-to-r from-emerald-950/40 to-slate-900/90 border border-emerald-500/30 text-slate-200 space-y-1 shadow-md transition-all"
            : "rounded-2xl p-3.5 bg-slate-950/80 border border-slate-800 text-slate-300 space-y-1 transition-all";

          bannerEl.innerHTML = `
            <div class="flex items-center gap-2">
              <span class="text-xs font-bold flex items-center gap-1.5 text-slate-100">
                <i class="fa-solid ${weekStats.outlookIcon}"></i>
                ${safeHeadline}
              </span>
            </div>
            <p class="text-xs text-slate-400 leading-normal">
              ${safeMessage}
            </p>
          `;
        }
      }

      // 5. Render Metric Cards
      const workoutsMetricEl = document.getElementById('home-metric-workouts');
      if (workoutsMetricEl) workoutsMetricEl.innerText = `${weekStats.daysCount} / 7`;
      const workoutsSubEl = document.getElementById('home-metric-workouts-sub');
      if (workoutsSubEl) {
        workoutsSubEl.innerText = weekStats.daysCount >= 3 ? "Champion pace!" : "Sessions logged";
      }
      const volumeMetricEl = document.getElementById('home-metric-volume');
      if (volumeMetricEl) volumeMetricEl.innerText = weekStats.weekVolume.toLocaleString();
      const setsMetricEl = document.getElementById('home-metric-sets');
      if (setsMetricEl) setsMetricEl.innerText = weekStats.weekSetsCount.toString();
      const streakMetricEl = document.getElementById('home-metric-streak');
      if (streakMetricEl) streakMetricEl.innerText = `${weekStats.streak}d`;

      // 6. Squad Pulse Card
      const squadPulseCard = document.getElementById('home-squad-pulse-card');
      if (squadPulseCard) {
        let squads = [];
        try {
          if (typeof getSquads === 'function') squads = getSquads();
        } catch (e) {}

        if (squads.length === 0) {
          squadPulseCard.innerHTML = `
            <div class="flex items-center justify-between gap-3">
              <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-purple-500/10 text-purple-400 border border-purple-500/30 flex items-center justify-center text-sm shrink-0">
                  <i class="fa-solid fa-people-group"></i>
                </div>
                <div>
                  <div class="text-xs font-bold text-slate-200">Accountability Squads</div>
                  <div class="text-[11px] text-slate-400">Join a squad to train together and celebrate teammates.</div>
                </div>
              </div>
              <button type="button" onclick="triggerHaptic('light'); switchTab('squads')" class="text-xs font-bold text-purple-400 hover:text-purple-300 bg-purple-500/10 border border-purple-500/25 px-2.5 py-1.5 rounded-xl transition shrink-0">
                Explore Squads
              </button>
            </div>
          `;
        } else {
          const todayKey = typeof getLocalDateKey === 'function' ? getLocalDateKey() : (typeof getETDateKey === 'function' ? getETDateKey() : new Date().toISOString().slice(0, 10));
          let teammatesCompletedToday = 0;
          let teammatesLiftingNow = 0;
          squads.forEach(sq => {
            (sq.members || []).forEach(m => {
              if (m.id !== user.id && m.email !== user.email) {
                if (m.isWorkingOut && (typeof isMemberWorkoutActive !== 'function' || isMemberWorkoutActive(m))) teammatesLiftingNow++;
                if (m.completedToday && m.completedDate === todayKey) teammatesCompletedToday++;
              }
            });
          });

          squadPulseCard.innerHTML = `
            <div class="flex items-center justify-between gap-3">
              <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-purple-500/15 text-purple-400 border border-purple-500/30 flex items-center justify-center text-sm shrink-0">
                  <i class="fa-solid fa-shield-halved"></i>
                </div>
                <div>
                  <div class="text-xs font-bold text-slate-200">${squads.length} Active Squad${squads.length > 1 ? 's' : ''}</div>
                  <div class="text-[11px] text-slate-400">
                    ${teammatesLiftingNow > 0 ? `<span class="text-emerald-400 font-semibold"><i class="fa-solid fa-circle text-[8px] animate-pulse"></i> ${teammatesLiftingNow} lifting now</span> • ` : ''}
                    <span>${teammatesCompletedToday} teammate${teammatesCompletedToday === 1 ? '' : 's'} showed up today</span>
                  </div>
                </div>
              </div>
              <button type="button" onclick="triggerHaptic('light'); switchTab('squads')" class="text-xs font-bold text-purple-400 hover:text-purple-300 bg-purple-500/10 border border-purple-500/25 px-2.5 py-1.5 rounded-xl transition shrink-0">
                View Squads
              </button>
            </div>
          `;
        }
      }
    }

